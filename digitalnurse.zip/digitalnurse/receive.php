<?php
// Database connection settings
$servername = "localhost"; // or your server IP
$username = "root";
$password = "";
$dbname = "digitalnurse_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the POST data exists
if (isset($_POST['hexSys']) && isset($_POST['hexDias']) && isset($_POST['hexBPM'])) {
    // Sanitize inputs
    $hexSys = intval($_POST['hexSys']);
    $hexDias = intval($_POST['hexDias']);
    $hexBPM = intval($_POST['hexBPM']);
    
    // Prepare the SQL statement
    $sql = "INSERT INTO data_bloodpresure (hexSys, hexDias, hexBPM, timestamp) VALUES (?, ?, ?, NOW())";

    // Prepare and bind
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $hexSys, $hexDias, $hexBPM);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close statement
    $stmt->close();
} else {
    echo "No data received!";
}

// Close connection
$conn->close();
?>
